"""
Tests Package Initialization
"""
